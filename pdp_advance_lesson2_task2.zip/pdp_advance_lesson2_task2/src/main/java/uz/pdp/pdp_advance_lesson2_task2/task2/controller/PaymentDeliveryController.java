package uz.pdp.pdp_advance_lesson2_task2.task2.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;
import uz.pdp.pdp_advance_lesson2_task2.task2.entity.PaymentDeliveryEntity;
import uz.pdp.pdp_advance_lesson2_task2.task2.service.PaymentDeliveryService;

import java.util.List;

@RestController
@RequestMapping("/api/payment-delivery")
public class PaymentDeliveryController {

    @Autowired
    PaymentDeliveryService paymentDeliveryService;

    @PreAuthorize("hasAnyRole('SUPER_ADMIN', 'MODERATOR', 'OPERATOR')")

    @GetMapping
    public List<PaymentDeliveryEntity> getAllPaymentDeliveryData() {
        return paymentDeliveryService.paymentDeliveryEntityList();
    }

    @PreAuthorize("hasAnyRole('SUPER_ADMIN', 'MODERATOR', 'OPERATOR')")

    @GetMapping("/{id}")
    public PaymentDeliveryEntity getPaymentDeliveryById(@PathVariable Long id) {
        return paymentDeliveryService.getPaymentDeliveryById(id);
    }

    @PreAuthorize("hasAnyRole('SUPER_ADMIN', 'MODERATOR', 'OPERATOR')")

    @PostMapping
    public PaymentDeliveryEntity savePaymentDeliveryData(@RequestBody PaymentDeliveryEntity paymentDeliveryEntity) {
        return paymentDeliveryService.savePaymentDeliveryData(paymentDeliveryEntity);
    }

    @PreAuthorize("hasAnyRole('SUPER_ADMIN', 'MODERATOR')")

    @PutMapping("/{id}")
    public PaymentDeliveryEntity updatePaymentDelivery(@PathVariable Long id, @RequestBody PaymentDeliveryEntity updatedPaymentDelivery) {
        return paymentDeliveryService.updatePaymentDelivery(id, updatedPaymentDelivery);
    }

    @PreAuthorize("hasAnyRole('SUPER_ADMIN')")

    @DeleteMapping("/{id}")
    public void deletePaymentDelivery(@PathVariable Long id) {
        paymentDeliveryService.deletePaymentDelivery(id);
    }
}

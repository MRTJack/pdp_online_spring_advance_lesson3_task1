package uz.pdp.pdp_advance_lesson2_task2.task2.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import uz.pdp.pdp_advance_lesson2_task2.task2.entity.SupplierEntity;
import uz.pdp.pdp_advance_lesson2_task2.task2.repo.SupplierRepository;

import java.util.List;

@Service
public class SupplierService {

    @Autowired
    SupplierRepository supplierRepository;

    public List<SupplierEntity> getAllSuppliers() {
        return supplierRepository.findAll();
    }

    public SupplierEntity getSupplierById(Long id) {
        return supplierRepository.findById(id).orElse(null);
    }

    public SupplierEntity saveSupplier(SupplierEntity supplier) {
        return supplierRepository.save(supplier);
    }

    public SupplierEntity updateSupplier(Long id, SupplierEntity updatedSupplier) {
        SupplierEntity existingSupplier = supplierRepository.findById(id).orElse(null);

        if (existingSupplier != null) {
            existingSupplier.setName(updatedSupplier.getName());
            existingSupplier.setContactPerson(updatedSupplier.getContactPerson());
            existingSupplier.setContactEmail(updatedSupplier.getContactEmail());
            return supplierRepository.save(existingSupplier);
        }

        return null;
    }

    public void deleteSupplier(Long id) {
        supplierRepository.deleteById(id);
    }
}


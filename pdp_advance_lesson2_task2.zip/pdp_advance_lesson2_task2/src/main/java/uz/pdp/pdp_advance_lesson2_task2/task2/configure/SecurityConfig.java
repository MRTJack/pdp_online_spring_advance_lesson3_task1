package uz.pdp.pdp_advance_lesson2_task2.task2.configure;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpMethod;
import org.springframework.security.config.annotation.SecurityConfigurerAdapter;
import org.springframework.security.config.annotation.method.configuration.EnableGlobalMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.provisioning.InMemoryUserDetailsManager;
import org.springframework.security.web.DefaultSecurityFilterChain;

import static org.springframework.security.config.Customizer.withDefaults;

@Configuration
@EnableWebSecurity
@EnableGlobalMethodSecurity(prePostEnabled = true)
public class SecurityConfig {

    @Bean
    public UserDetailsService userDetailsService() {
        // Create users with different roles
        return new InMemoryUserDetailsManager(
                User.withUsername("admin").password(passwordEncoder().encode("admin")).roles("SUPER_ADMIN").build(),
                User.withUsername("moderator").password(passwordEncoder().encode("moderator")).roles("MODERATOR").build(),
                User.withUsername("operator").password(passwordEncoder().encode("operator")).roles("OPERATOR").build()
        );
    }

    @Bean
    public PasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder();
    }

    @Configuration
    public static class CustomSecurityConfigurer extends SecurityConfigurerAdapter<DefaultSecurityFilterChain, HttpSecurity> {

        @Bean
        public SecurityConfigurerAdapter<DefaultSecurityFilterChain, HttpSecurity> securityConfigurerAdapter() {
            return new SecurityConfigurerAdapter<>() {
                @Override
                public void configure(HttpSecurity http) throws Exception {
                    http
                            .authorizeRequests(authorizeRequests ->
                                    authorizeRequests
                                            .dispatcherTypeMatchers(HttpMethod.valueOf("/public/**")).permitAll()
                                            .dispatcherTypeMatchers(HttpMethod.valueOf("/admin/**")).hasRole("SUPER_ADMIN")
                                            .dispatcherTypeMatchers(HttpMethod.valueOf("/moderator/**")).hasRole("MODERATOR")
                                            .dispatcherTypeMatchers(HttpMethod.valueOf("/operator/**")).hasRole("OPERATOR")
                                            .anyRequest().authenticated()
                            )
                            .formLogin(withDefaults())
                            .httpBasic(withDefaults());
                }
            };
        }
    }
}

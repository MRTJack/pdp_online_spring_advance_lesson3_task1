package uz.pdp.pdp_advance_lesson2_task2.task2.service;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import uz.pdp.pdp_advance_lesson2_task2.task2.entity.ReviewsEntity;
import uz.pdp.pdp_advance_lesson2_task2.task2.repo.ReviewsRepository;

import java.util.List;

@Service
public class ReviewsService {


    @Autowired
    ReviewsRepository reviewsRepository;
    public List<ReviewsEntity> getAllReviews() {
        return reviewsRepository.findAll();
    }

    public ReviewsEntity getReviewById(Long id) {
        return reviewsRepository.findById(id).orElse(null);
    }

    public ReviewsEntity saveReview(ReviewsEntity review) {
        return reviewsRepository.save(review);
    }

    public ReviewsEntity updateReview(Long id, ReviewsEntity updatedReview) {
        ReviewsEntity existingReview = reviewsRepository.findById(id).orElse(null);

        if (existingReview != null) {
            existingReview.setUserName(updatedReview.getUserName());
            existingReview.setComment(updatedReview.getComment());
            return reviewsRepository.save(existingReview);
        }

        return null;
    }

    public void deleteReview(Long id) {
        reviewsRepository.deleteById(id);
    }
}


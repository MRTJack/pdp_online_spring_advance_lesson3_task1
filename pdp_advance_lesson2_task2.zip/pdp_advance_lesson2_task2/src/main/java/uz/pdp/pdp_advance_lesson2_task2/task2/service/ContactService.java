package uz.pdp.pdp_advance_lesson2_task2.task2.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import uz.pdp.pdp_advance_lesson2_task2.task2.entity.ContactEntity;
import uz.pdp.pdp_advance_lesson2_task2.task2.repo.ContactRepository;

import java.util.List;

@Service
public class ContactService {

    @Autowired
    ContactRepository contactRepository;

    public List<ContactEntity> getAllContacts() {
        return contactRepository.findAll();
    }

    public ContactEntity getContactById(Long id) {
        return contactRepository.findById(id).orElse(null);
    }

    public ContactEntity saveContact(ContactEntity contact) {
        return contactRepository.save(contact);
    }

    public ContactEntity updateContact(Long id, ContactEntity updatedContact) {
        ContactEntity existingContact = contactRepository.findById(id).orElse(null);

        if (existingContact != null) {
            existingContact.setPhoneNumber(updatedContact.getPhoneNumber());
            existingContact.setAddress(updatedContact.getAddress());
            existingContact.setEmail(updatedContact.getEmail());
            return contactRepository.save(existingContact);
        }

        return null;
    }

    public void deleteContact(Long id) {
        contactRepository.deleteById(id);
    }
}

